function myFunction() {
    var x = document.querySelector('#pass');
    var y = document.querySelector('#eye');
    var z = document.querySelector('#eyeSlash');


    if (x.type === 'password') {
        x.type = 'text';
        y.style.display = "block";
        y.style.marginTop = "2px";
        z.style.display = 'none';
    } else {
        x.type = 'password';
        y.style.display = 'none';
        z.style.display = 'block';
        z.style.marginTop = "2px";
        z.style.marginRight = "-1px";
    }
}
function myFunction2() {
    var x = document.querySelector('#pass2');
    var y = document.querySelector('#eye2');
    var z = document.querySelector('#eyeSlash2');


    if (x.type === 'password') {
        x.type = 'text';
        y.style.display = "block";
        y.style.marginTop = "2px";
        z.style.display = 'none';
    } else {
        x.type = 'password';
        y.style.display = 'none';
        z.style.display = 'block';
        z.style.marginTop = "2px";
        z.style.marginRight = "-1px";
    }
}
function myFunction3() {
    var x = document.querySelector('#pass3');
    var y = document.querySelector('#eye3');
    var z = document.querySelector('#eyeSlash3');


    if (x.type === 'password') {
        x.type = 'text';
        y.style.display = "block";
        y.style.marginTop = "2px";
        z.style.display = 'none';
    } else {
        x.type = 'password';
        y.style.display = 'none';
        z.style.display = 'block';
        z.style.marginTop = "2px";
        z.style.marginRight = "-1px";
    }
}
function myFunction_1() {
    var x = document.querySelector('#pass_1');
    var y = document.querySelector('#eye_1');
    var z = document.querySelector('#eyeSlash_1');


    if (x.type === 'password') {
        x.type = 'text';
        y.style.display = "block";
        y.style.marginTop = "2px";
        z.style.display = 'none';
    } else {
        x.type = 'password';
        y.style.display = 'none';
        z.style.display = 'block';
        z.style.marginTop = "2px";
        z.style.marginRight = "-1px";
    }
}
function myFunction_2() {
    var x = document.querySelector('#pass_2');
    var y = document.querySelector('#eye_2');
    var z = document.querySelector('#eyeSlash_2');


    if (x.type === 'password') {
        x.type = 'text';
        y.style.display = "block";
        y.style.marginTop = "2px";
        z.style.display = 'none';
    } else {
        x.type = 'password';
        y.style.display = 'none';
        z.style.display = 'block';
        z.style.marginTop = "2px";
        z.style.marginRight = "-1px";
    }
}
