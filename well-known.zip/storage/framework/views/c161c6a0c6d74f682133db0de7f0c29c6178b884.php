
<?php $__env->startSection('title','Add Student'); ?>
<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-3">
        <div class="card">
            <div class="stat-widget-one">
                <div class="stat-icon dib"><i class="ti-user color-primary border-primary"></i>
                </div>
                <div class="stat-content dib">
                    <div class="stat-text">
                        <h4>Ten (10)</h4>
                    </div>
                    <div class="stat-text">Total Student</div>
                    <div class="stat-digit text-danger">
                        <strong>70</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="stat-widget-one">
                <div class="stat-icon dib"><i class="ti-user color-primary border-primary"></i>
                </div>
                <div class="stat-content dib">
                    <div class="stat-text">
                        <h4>Nine (09)</h4>
                    </div>
                    <div class="stat-text">Total Student</div>
                    <div class="stat-digit text-danger">
                        <strong>70</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="stat-widget-one">
                <div class="stat-icon dib"><i class="ti-user color-primary border-primary"></i>
                </div>
                <div class="stat-content dib">
                    <div class="stat-text">
                        <h4>Eight</h4>
                    </div>
                    <div class="stat-text">Total Student</div>
                    <div class="stat-digit text-danger">
                        <strong>67</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="stat-widget-one">
                <div class="stat-icon dib"><i class="ti-user color-primary border-primary"></i>
                </div>
                <div class="stat-content dib">
                    <div class="stat-text">
                        <h4>Seven</h4>
                    </div>
                    <div class="stat-text">Total Student</div>
                    <div class="stat-digit text-danger">
                        <strong>77</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="stat-widget-one">
                <div class="stat-icon dib"><i class="ti-user color-primary border-primary"></i>
                </div>
                <div class="stat-content dib">
                    <div class="stat-text">
                        <h4>Six</h4>
                    </div>
                    <div class="stat-text">Total Student</div>
                    <div class="stat-digit text-danger">
                        <strong>89</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 p-r-0 title-margin-right">
        <div class="page-header">
            <div class="page-title">
                <h1>Add, <span>New Informations</span></h1>
                <a href="" class="btn btn-primary mr-2">
                    <span class="ti-plus mr-2"></span>Add Student</a>
                <a href="" class="btn btn-success mr-2"><span class="ti-plus mr-2"></span>Add Notice</a>
                <a href="" class="btn btn-info mr-2"><span class="ti-menu mr-2"></span>Pending Student</a>
                <a href="" class="btn btn-warning mr-2"><span class="ti-menu mr-2"></span>Pending Marks</a>
                <a href="" class="btn btn-danger"><span class="ti-bookmark mr-2"></span>BookMark Student</a>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-8 p-r-0 title-margin-right">
        <div class="page-header">
            <div class="page-title">
                <h1>Recently Added students, <span>Last (10)</span></h1>
            </div>
        </div>
    </div>
    <!-- /# column -->
    <div class="col-lg-4 p-l-0 title-margin-left">
        <div class="page-header">
            <div class="page-title">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                    <li class="breadcrumb-item active">Table-Export</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- /# column -->
</div>
<!-- /# row -->
<section id="main-content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="bootstrap-data-table-panel">
                    <div class="table-responsive">
                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Roll</th>
                                    <th>Class</th>
                                    <th>Result</th>
                                    <th>Section</th>
                                    <th>Manage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Alex Crry</td>
                                    <td>07</td>
                                    <td>class 7</td>
                                    <td>A+</td>
                                    <td>Science</td>
                                    <td class="manage-icon">
                                        <a href="<?php echo e(url('dashboard/table/add')); ?>"><i class="ti-plus"></i></a>
                                        <a href=""><i class="ti-pencil-alt"></i></a>
                                        <a href=""><i class="ti-trash"></i></a>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lara_Result\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>