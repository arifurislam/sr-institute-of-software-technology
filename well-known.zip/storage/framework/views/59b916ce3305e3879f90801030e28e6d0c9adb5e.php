
<?php $__env->startSection('title','all-users'); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-12 p-r-0 title-margin-right">
        <div class="page-header">
            <div class="page-title">
                <h1>Hello, <span>Welcome Here</span> </h1>
                <h1 class="text-info">Total Users( <?php echo e($tUsers); ?> )</h1>
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title border-bottom mb-3 pb-3">
                <div class="d-flex justify-content-between">
                    <h4>All User Informations </h4>
                    <a href="<?php echo e(url('dashboard/users/create')); ?>" class="btn btn-primary"><i class="ti-plus mr-2"></i> Add
                        User</a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped mb-5">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Time</th>
                                <th>Manage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($data->name); ?></th>
                                <td><?php echo e(Str::limit($data->email, '15')); ?></td>
                                <td>
                                    <?php if($data->role_id == 1): ?>
                                    <span class="badge badge-primary">Admin</span>
                                    <?php else: ?>
                                    <span class="badge badge-info">Author</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($data->created_at->format('m - D : h ')); ?></td>
                                <td class="manage-icons">
                                    <a href="<?php echo e(url('dashboard/users/'.$data->id)); ?>"><i class="ti-plus"></i></a>
                                    <a href="<?php echo e(url('dashboard/users/'.$data->id. '/edit')); ?>"><i
                                            class="ti-pencil"></i></a>
                                    <form action="<?php echo e(url('dashboard/users/'.$data->id)); ?>" method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-primary px-1 py-0"><i
                                                class="ti-trash"></i></button>
                                    </form>
                                    <!-- <a href="<?php echo e(url('dashboard/users/'.$data->id)); ?>"><i class="ti-trash"></i></a> -->
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-end">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/srinstit/public_html/resources/views/admin/users/index.blade.php ENDPATH**/ ?>