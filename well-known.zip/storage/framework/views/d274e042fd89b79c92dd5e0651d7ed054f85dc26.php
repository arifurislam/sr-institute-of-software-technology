
<?php $__env->startSection('title','add-student'); ?>

<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-8 p-r-0 title-margin-right">
        <div class="page-header">
            <div class="page-title">
                <h1>Hello, <span>Welcome Here</span></h1>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h4>Basic Elements</h4>

            </div>
            <div class="card-body">
                <div class="basic-elements">
                    <form>
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-3 text-right">
                                            <label class="mb-0">Student Name <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" value="Some text value...">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input id="example-email" class="form-control" type="email" placeholder="Email"
                                        name="example-email">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="form-control" type="password" value="password">
                                </div>
                                <div class="form-group">
                                    <label>Text area</label>
                                    <textarea class="form-control" rows="3" placeholder="Text input"></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Readonly</label>
                                    <input class="form-control" type="text" value="Readonly value" readonly="">
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="form-group">
                                    <label>Input Select</label>
                                    <select class="form-control">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lara_Result\resources\views/admin/students/add.blade.php ENDPATH**/ ?>