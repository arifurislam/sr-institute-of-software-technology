
<?php $__env->startSection('title','singel-info'); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-12 p-r-0 title-margin-right">
        <div class="page-header">
            <div class="page-title">
                <h1>Hello, <span>Welcome Here</span></h1>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <table class="table table-striped table-bordered view_table_custom">
            <tr>
                <td>Name</td>
                <td>:</td>
                <td><?php echo e($data->name); ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>:</td>
                <td><?php echo e($data->email); ?></td>
            </tr>
            <tr>
                <td>Contact</td>
                <td>:</td>
                <td><?php echo e($data->number); ?></td>
            </tr>
            <tr>
                <td>Gender</td>
                <td>:</td>
                <td><?php if($data->gender_id == 1): ?>
                    <?php echo e('Male'); ?>

                  <?php else: ?>
                    <?php echo e('Female'); ?>

                  <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Qualifications</td>
                <td>:</td>
                <td>
                  <?php if($data->qua_id == 1): ?>
                    <?php echo e('Diploma-In-Engineering Complete'); ?>

                  <?php else: ?>
                    <?php echo e('Graduation Complete'); ?>

                  <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Age</td>
                <td>:</td>
                <td><?php echo e($data->age . ' Years Old'); ?></td>
            </tr>
            <tr>
                <td>Registration Time</td>
                <td>:</td>
                <td><?php echo e($data->created_at->format('h: i: s a  Y - M - D')); ?></td>
            </tr>
        </table>
    </div>
    <div class="col-md-2"></div>
</div>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/srinstit/public_html/resources/views/admin/contact/show.blade.php ENDPATH**/ ?>