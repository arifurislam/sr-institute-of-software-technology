
<?php $__env->startSection('title','add-mark-six'); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-8 p-r-0 title-margin-right">
        <div class="page-header">
            <div class="page-title">
                <h1>Hello, <span>Welcome Here</span></h1>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <form action="<?php echo e(url('')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-title border-bottom d-flex justify-content-between py-3">
                    <h4 class="mb-0"><span class="ti-plus mr-2"></span> Add Student Mark</h4>
                    <a class="btn btn-danger" href="<?php echo e(url('/dashboard/six-class')); ?>"><span
                            class="ti-arrow-left pr-3"></span>All Student</a>
                </div>
                <div class="card-body">
                    <div class="basic-elements">

                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-3 text-right">
                                            <label class="mb-0">Student's Name : <span>*</span></label>
                                        </div>
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" value="<?php echo e(($student->name)); ?>" disabled>

                                        </div>

                                        <div class="col-lg-3 text-right">
                                            <label class="mb-0">Student's Father Name : <span>*</span></label>
                                        </div>
                                        <div class="col-lg-9">
                                            <input type="text"
                                                class="form-control" value="<?php echo e(($student->father)); ?>" disabled>
                                        </div>
                                        <div class="col-lg-3 text-right">
                                            <label class="mb-0">Class Roll : <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-lg-9">
                                            <input type="text" name="roll"
                                                class="form-control <?php echo e($errors->has('roll')? 'has-error':''); ?>"
                                                placeholder="Class Roll is here..." value="<?php echo e(old('role')); ?>">
                                            <?php if($errors->has('roll')): ?>
                                            <span class="invalid-feedback mb-0" role="alert">
                                                <strong><?php echo e($errors->first('roll')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-lg-3 text-right">
                                            <label class="mb-0">Class 06 : <span>*</span></label>
                                        </div>
                                        <div class="col-lg-9">
                                            <input type="text" name="class" class="form-control"
                                                placeholder="Student From Class six..." disabled>
                                        </div>
                                        <div class="col-lg-3 text-right">
                                            <label class="mb-0">Section : <span>*</span></label>
                                        </div>
                                        <div class="col-lg-9">
                                            <input type="text" name="section" class="form-control" placeholder="N / A"
                                                disabled>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="card-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-10">
                                <div class="d-flex justify-content-end">
                                    <a href="" class="btn btn-danger mr-3">Back</a>
                                    <button type="submit" class="btn btn-success"><span
                                            class="ti-upload"></span>Upload Mark</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lara_Result\resources\views/admin/class-6/add-mark.blade.php ENDPATH**/ ?>