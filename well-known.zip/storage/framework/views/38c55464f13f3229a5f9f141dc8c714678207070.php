
<?php $__env->startSection('title','class-six'); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('admin')); ?>/css/lib/data-table/buttons.bootstrap.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-12 p-r-0 title-margin-right">
        <div class="page-header">
            <div class="page-title">
                <h1>Hello, <span>Welcome Here</span></h1>
                <a href="<?php echo e(url('dashboard/six-class/add')); ?>" class="btn btn-primary mr-2"><span class="ti-plus mr-2"></span>Add Student</a>
                <a href="" class="btn btn-success mr-2"><span class="ti-menu mr-2"></span>All Student</a>
                <a href="" class="btn btn-info mr-2"><span class="ti-plus mr-2"></span>Add Mark</a>
                <a href="" class="btn btn-warning mr-2"><span class="ti-menu mr-2"></span>All Mark</a>
                <a href="" class="btn btn-danger"><span class="ti-bookmark mr-2"></span>CGPA</a>
            </div>
        </div>
    </div>
</div>
<!-- /# row -->
<section id="main-content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="bootstrap-data-table-panel">
                    <div class="table-responsive">
                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Roll</th>
                                    <th>Name</th>
                                    <th>Class</th>
                                    <th>CGPA</th>
                                    <th>Marks</th>
                                    <th>Status</th>
                                    <th>Manage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($student->roll); ?></td>
                                    <td><?php echo e($student->name); ?></td>
                                    <td><?php if($student->class_id == 6): ?>
                                        <span class="badge badge-primary"><?php echo e('6'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e('...'); ?></td>
                                    <td><?php echo e('...'); ?></td>
                                    <td>
                                        <?php if($student->status == 1): ?>
                                            <span class="badge badge-info"><?php echo e('published'); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-warning"><?php echo e('un published'); ?></span>
                                        <?php endif; ?>

                                    </td>
                                    <td class="manage-icon">
                                        <a href="<?php echo e(url('dashboard/six-class/' . $student->slug )); ?>"><i class="ti-plus"></i></a>
                                        <a href=""><i class="ti-pencil-alt"></i></a>
                                        <a href=""><i class="ti-trash"></i></a>
                                        <a href="<?php echo e(url('dashboard/six-class/add-mark/' .$student->slug)); ?>">mark</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

</section>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/datatables.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/buttons.flash.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/jszip.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/pdfmake.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/vfs_fonts.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/buttons.print.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/datatables-init.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lara_Result\resources\views/admin/class-6/index.blade.php ENDPATH**/ ?>