
<?php $__env->startSection('title','all-contacts'); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('admin')); ?>/css/lib/data-table/buttons.bootstrap.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-12 p-r-0 title-margin-right">
        <div class="page-header">
            <div class="page-title">
                <h1>Hello, <span>Welcome Here</span> </h1>
                <h1 class="text-info">Total (<?php echo e($contactsC); ?>)</h1>
            </div>
        </div>
    </div>
</div>
<!-- /# row -->
<section id="main-content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="bootstrap-data-table-panel">
                    <div class="table-responsive">
                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th># ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Qualification</th>
                                    <th>Gender</th>
                                    <th>age</th>
                                    <th>Time</th>
                                    <th>Manage</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($contact->id); ?></td>
                                    <td><?php echo e($contact->name); ?></td>
                                    <td><?php echo e(Str::limit($contact->email ,25)); ?></td>
                                    <td><?php echo e($contact->number); ?></td>
                                    <td>
                                    <?php echo e($contact->qua_id == 1 ? 'Diploma-In-Engineering': 'Graduation'); ?>

                                    </td>
                                    <td>
                                    <?php echo e($contact->gender_id == 1 ? 'Male': 'Female'); ?>

                                    </td>
                                    <td><?php echo e($contact->age); ?></td>
                                    <td><?php echo e($contact->created_at->format('h: i: a  M-d')); ?></td>
                                    <td class="manage-icon">
                                        <a href="<?php echo e(url('dashboard/contact/show/' .$contact->id)); ?>"><i
                                                class="ti-plus"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

</section>

<?php $__env->startPush('js'); ?>

<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/datatables.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/buttons.flash.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/jszip.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/pdfmake.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/vfs_fonts.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/buttons.print.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/js/lib/data-table/datatables-init.js"></script>
<!-- <script type="text/javascript">
    $(document).ready(function () {
        $('#bootstrap-data-table-export').dataTable({
            
        });
    });

</script> -->

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\software-technology\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>