
<?php $__env->startSection('title','contact with us'); ?>
<?php $__env->startPush('web-css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('website'); ?>
<!-- page title -->
<section class="page-title-section overlay" data-background="<?php echo e(asset('website')); ?>/images/backgrounds/page-title.jpg">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <ul class="list-inline custom-breadcrumb">
                    <li class="list-inline-item"><a class="h2 text-primary font-secondary" href="@page-link">Contact
                            Us</a>
                    </li>
                    <li class="list-inline-item text-white h3 font-secondary @nasted"></li>
                </ul>
                <p class="text-lighten">Do you have other questions? SEIP Project student registration is open now,
                    If your want to attend SEIP project, fill up all the info below and and click 'Register Now' button.
                    we will knock you...</p>
            </div>
        </div>
    </div>
</section>
<!-- /page title -->

<!-- contact -->
<section class="section bg-gray">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="section-title">SEIP ProJect Registration</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-7 mb-4 mb-lg-0">
                <!-- bootstrap alert -->
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
                <!-- /bootstrap alert -->
                <form action="<?php echo e(url('/seip/registrations/stores')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div>
                        <div class="d-inline text-danger">*</div>
                        <input type="text" class="form-control mb-2 <?php echo e($errors->has('name')? 'has-error':''); ?>" id="name"
                            name="name" value="<?php echo e(old('name')); ?>" placeholder="Your Name">
                        <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback mb-0" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="d-inline text-danger">*</div>
                        <input type="email" class="form-control mb-2 <?php echo e($errors->has('email')? 'has-error':''); ?>"
                            id="mail" name="email" value="<?php echo e(old('email')); ?>" placeholder="Your Email">
                        <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback mb-0" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="d-inline text-danger">*</div>
                        <input type="text" class="form-control mb-2 <?php echo e($errors->has('number')? 'has-error':''); ?>"
                            name="number" value="<?php echo e(old('number')); ?>" placeholder="Contact Number">
                        <?php if($errors->has('number')): ?>
                        <span class="invalid-feedback mb-0" role="alert">
                            <strong><?php echo e($errors->first('number')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="d-inline text-danger">*</div>
                        <input type="text" class="form-control mb-2 <?php echo e($errors->has('age')? 'has-error':''); ?>" name="age"
                            value="<?php echo e(old('age')); ?>" placeholder="Your Age">
                        <?php if($errors->has('age')): ?>
                        <span class="invalid-feedback mb-0" role="alert">
                            <strong><?php echo e($errors->first('age')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="d-inline text-danger">*</div>
                        <select name="gender" class="form-control mb-2 <?php echo e($errors->has('gender')? 'has-error':''); ?>">
                            <option>Select Your Gender</option>
                            <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gender->id); ?>"><?php echo e($gender->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('gender')): ?>
                        <span class="invalid-feedback mb-0" role="alert">
                            <strong><?php echo e($errors->first('gender')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="d-inline text-danger">*</div>
                        <select name="education"
                            class="form-control mb-3 <?php echo e($errors->has('education')? 'has-error':''); ?>">
                            <option>Qualifications</option>
                            <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('education')): ?>
                        <span class="invalid-feedback mb-0" role="alert">
                            <strong><?php echo e($errors->first('education')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-primary">Register Now</button>
                </form>
            </div>
            <div class="col-lg-5">
                <p class="mb-3">
                    SR Institute of Software Techonology is a growing IT company in Dhaka , Now SR Institute of Software
                    Techonology
                    arrange a SEIP project for young people.You can attends our SEIP projects as a learner...
                </p>
                <div class="mb-4">
                    <strong class="mb-3 d-block">Rules To Register : <br></strong>
                    <span class="mb-4 d-block"># To perticipate SEIP project you have to complete Diploma-In-Engineerin
                        or you
                        have to complete
                        Graduation and age should be 45 years or less.</span>
                    <span class="mb-4 d-block"># Fill up all the form with correct informations related to you.</span>
                    <span class="mb-4 d-inline-block"># If you face any kinds of problems to register or you want to know more info
                        about
                        SEIP,
                        plz contact with us,
                    </span>
                    <a href="tel: +880 1919414153" class="text-color h5 d-block">+880 1919414153</a>
                    <a href="mailto:training.sr.bteb@gmail.com"
                        class="mb-3 text-color h5 d-block">training.sr.bteb@gmail.com</a>
                    <p>Mohammadia Supper Market (3nd Floor),<br>
                        4 No Tollabag, Sobahanbag, (Opposit of A.R Plaza),<br>
                        Mirpur Road, Dhanmonddi Dhaka-1207.<br>
                </div>
            </div>
            </p>
        </div>
    </div>
    </div>
</section>
<!-- /contact -->


<?php $__env->startPush('web-js'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\software-technology\resources\views/website/contact.blade.php ENDPATH**/ ?>