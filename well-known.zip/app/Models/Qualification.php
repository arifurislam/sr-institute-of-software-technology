<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Qualification extends Model
{
    use HasFactory;

    // public function con()
    // {
    //     return $this->hasMany(Contact::class ,'qua_id','id');
    // }
}
